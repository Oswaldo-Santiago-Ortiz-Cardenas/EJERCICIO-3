﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sesion10Ejemplo02.interfaces
{
    public  class Aritmetica
    {

        public static int sumar(int numero1, int numero2)
        {
            return numero1 + numero2;
        }


        public static int restar(int numero1, int numero2)
        {
            return numero1 - numero2;
        }

        public static int multiplicar(int numero1, int numero2)
        {
            return numero1 * numero2;
        }

        public static int dividir(int numero1, int numero2)
        {
            return numero1 / numero2;
        }
    }
}
